window.open("../Options/Options.html");
